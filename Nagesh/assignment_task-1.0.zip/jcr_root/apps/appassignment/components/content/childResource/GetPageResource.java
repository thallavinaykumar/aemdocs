package apps.appassignment.components.content.childResource;

import com.adobe.cq.sightly.WCMUsePojo;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;

import com.day.cq.wcm.api.Page;
    
public class GetPageResource extends WCMUsePojo {
    private Page pagePath;
    private ResourceResolver resourceResolver;
    private Resource resource;
    @Override
    public void activate() throws Exception {

        String resourcePath = getProperties().get("pagePath", "");
        resourceResolver = getResourceResolver();
        if (!resourcePath.isEmpty()) {
            resource = resourceResolver.getResource(resourcePath);
            pagePath = resource.adaptTo(Page.class);
        }
    }

    public Page getPagePath() {
        return this.pagePath;
    }
}